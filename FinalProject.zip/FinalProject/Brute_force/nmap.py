import socket,sys,threading,time
from tkinter import *

# ==== Scan Vars ====
ip_s = 1
ip_f = 1024
log = []
ports = []
target = 'localhost'

# ==== Functions to scan ====
def scanPort(target, port):
	try:
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		s.settimeout(4)
		c = s.connect_ex((target, port))
		if c == 0:
			m = ' Port %d \t[open]' % (port,)
			log.append(m)
			ports.append(port)
			listbox.insert("end", str(m))
			updateResult()
		s.close()
	except OSError: print('> Too many open sockets. Port ' + str(port))
	except:
		c.close()
		s.close()
		sys.exit()
	sys.exit()

def updateResult():
	rtext = " [ " + str(len(ports)) + " / " + str(ip_f) + " ] ~ " + str(target)
	L8.configure(text = rtext)

def startScan():
	global ports, log, target, ip_f
	clearScan()
	log = []
	ports = []
	# Get ports ranges from GUI
	ip_s = int(L5.get())
	ip_f = int(L6.get())
	# Start writing the log file
	log.append('> Port Scanner')
	log.append('='*14 + '\n')
	log.append(' Target:\t' + str(target))

	try:
		target = socket.gethostbyname(str(L3.get()))
		log.append(' IP Adr.:\t' + str(target))
		log.append(' Ports: \t[ ' + str(ip_s) + ' / ' + str(ip_f) + ' ]')
		log.append('\n')
		# Lets start scanning ports!
		while ip_s <= ip_f:
			try:
				scan = threading.Thread(target=scanPort, args=(target, ip_s))
				scan.setDaemon(True)
				scan.start()
			except: time.sleep(0.01)
			ip_s += 1
	except:
		m = '> Target ' + str(L3.get()) + ' not found.'
		log.append(m)
		listbox.insert(0, str(m))

def saveScan():
	global log, target, ports, ip_f
	log[5] = " Result:\t[ " + str(len(ports)) + " / " + str(ip_f) + " ]\n"
	with open('portscan-'+str(target)+'.txt', mode='wt', encoding='utf-8') as myfile:
		myfile.write('\n'.join(log))

def clearScan():
	listbox.delete(0, 'end')

# ==== GUI ====
gui = Tk()
gui.title("Port Scanner")
gui.geometry("400x600+20+20")

# ==== Colors ====
fgc = 'Green'
bgc = 'Black'
dbg = 'Blue'
abg = 'Yellow'
pbc = "Grey"

#gui.tk_setPalette(background=pbc, foreground=fgc, activeBackground=fgc,activeForeground=bgc, highlightColor=m1c, highlightBackground=m1c)
gui.tk_setPalette(background=bgc, foreground=fgc, activeBackground=fgc,activeForeground=bgc, highlightColor=fgc, highlightBackground=fgc)

# ==== Labels ====
L1 = Label(gui, text = "Usage of Nmap",  font=("Helvetica", 16, 'underline'))
L1.place(x = 100, y = 10)

L2 = Label(gui, text = "Target: ")
L2.place(x = 16, y = 90)

L3 = Entry(gui, text = "localhost")
L3.place(x = 180, y = 90)
L3.insert(0, "localhost")

L4 = Label(gui, text = "Ports: ")
L4.place(x = 16, y = 158)

L5 = Entry(gui, text = "1")
L5.place(x = 180, y = 158, width = 95)
L5.insert(0, "1")

L6 = Entry(gui, text = "1024")
L6.place(x = 290, y = 158, width = 95)
L6.insert(0, "1024")

L7 = Label(gui, text = "Results: ")
L7.place(x = 16, y = 220)

L8 = Label(gui, text = "[ ... ]")
L8.place(x = 180, y = 220)

# ==== Ports list ====
frame = Frame(gui)
frame.place(x = 16, y = 275, width = 370, height = 215)

listbox = Listbox(frame, width = 59, height = 6)
listbox.place(x = 0, y = 0)
listbox.bind('<<ListboxSelect>>')

scrollbar = Scrollbar(frame)
scrollbar.pack(side=RIGHT, fill=Y)

listbox.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=listbox.yview)

# ==== Buttons ====
B1 = Button(gui, text = "Start Scan", command=startScan)
B1.place(x = 16, y = 500, width = 170)

# ==== Start GUI ====
gui.mainloop()