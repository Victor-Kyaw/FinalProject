import tkinter as tk
import subprocess

def run_nmap_tk():
    # To open nmap
    subprocess.run(["python3", "Brute_force/nmap.py"])

def run_brute_force_gui():
    # To open the Bruteforce attack
    subprocess.run(["python3", "Brute_force/Brute_Force_update.py", "Brute_force/password.txt"])

root = tk.Tk()
root.title("Main Page")
root.geometry("300x100")

btn_program_1 = tk.Button(root, text="Run Nmap", command=run_nmap_tk)
btn_program_1.pack(pady=10)

btn_program_2 = tk.Button(root, text="Run Brute Force Attack GUI", command=run_brute_force_gui)
btn_program_2.pack(pady=10)

root.mainloop()
